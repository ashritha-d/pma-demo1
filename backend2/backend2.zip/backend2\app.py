from flask import Flask
from flask_cors import CORS
from routers.auth import auth_bp
from routers.owners import owners_bp
from routers.proporty import property_bp
from routers.fintrans import fintrans_bp
from routers.servTrans import servtrans_bp
from routers.contract import contract_bp
from routers.tanant import tenant_bp
from routers.users import users_bp
from routers.reports import reports_bp

app = Flask(__name__)
app.secret_key = "secret"
CORS(app, supports_credentials=True, origins=[
    "http://localhost:3000",
    "http://127.0.0.1:3000"
])

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(owners_bp)
app.register_blueprint(property_bp)
app.register_blueprint(fintrans_bp)
app.register_blueprint(servtrans_bp)
app.register_blueprint(contract_bp)
app.register_blueprint(tenant_bp)
app.register_blueprint(users_bp)
app.register_blueprint(reports_bp)

if __name__ == "__main__":
    app.run(debug=True)